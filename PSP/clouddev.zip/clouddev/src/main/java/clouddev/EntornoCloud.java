package clouddev;

import java.time.LocalDateTime;
import java.util.concurrent.Semaphore;

public class EntornoCloud {
	private Semaphore semaforoEDF;
	private Semaphore semaforoEPP;

	public EntornoCloud(Semaphore semaforoEDF, Semaphore semaforoEPP) {
		this.semaforoEDF = semaforoEDF;
		this.semaforoEPP = semaforoEPP;

	}
	public void iniciasesionEDF() {
		try {
			if(semaforoEDF.tryAcquire()) {
			semaforoEDF.acquire();
			System.out.println(Thread.currentThread().getName() + " ha iniciado sesion en el Entorno EDF a las " + LocalDateTime.now());

			Thread.sleep(5000);
			}
			else{
				System.out.println(Thread.currentThread().getName() + "no ha iniciado sesion en el Entorno EDF a las " + LocalDateTime.now());

			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			semaforoEDF.release();
		}}
	
	public void iniciasesionEPP() {
		try {
			if(semaforoEPP.tryAcquire()) {
			semaforoEPP.acquire();
			System.out.println(Thread.currentThread().getName() + " ha iniciado sesion en el Entorno EDF a las " + LocalDateTime.now());

			Thread.sleep(5000);
			}
			else {
				System.out.println(Thread.currentThread().getName() + "no ha iniciado sesion en el Entorno EDF a las " + LocalDateTime.now());
				
			}
		
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			semaforoEPP.release();
		}}
	
}