package clouddev;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Semaphore;

public class GestionaEntornoCloud {
	public static void main(String[] args) {

		Semaphore semaforoEDF= new Semaphore(20);
		Semaphore semaforoEPP= new Semaphore(8);
		EntornoCloud entorno = new EntornoCloud(semaforoEDF,semaforoEPP);
		
		
		List<Thread> hilos = new ArrayList<>();
		
		for(int i = 0; i < 35; i++)
		{
			hilos.add(new Desarrollador( "EDF",entorno, "Desarrollador EDF " +i, semaforoEDF, semaforoEPP ));
		}	
		for(int i = 0; i < 15; i++)
		{
			hilos.add(new Desarrollador( "EPP",entorno, "Desarrollador EPP " +i, semaforoEDF, semaforoEPP ));
		}		
		
		for(Thread hilo : hilos)
		{
			hilo.start();
		}		
		
		for (Thread hilo : hilos) {
			try {
				hilo.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}}

