package clouddev;

import java.time.LocalDateTime;
import java.util.concurrent.Semaphore;

public class Desarrollador extends Thread{

	private EntornoCloud entorno;
	private String nombre;
	private String tipoentorno;
	private Semaphore semaforoEDF;
	private Semaphore semaforoEPP;

	
	
	
	public Desarrollador(String tipoentorno, EntornoCloud entorno, String nombre,Semaphore semaforoEDF, Semaphore semaforoEPP ) {
		super();
		this.tipoentorno= tipoentorno;
		this.entorno = entorno;
		this.nombre = nombre;

	
	}

	

	public EntornoCloud getEntorno() {
		return entorno;
	}



	public void setEntorno(EntornoCloud entorno) {
		this.entorno = entorno;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
		
	}


	public String getTipoentorno() {
		return tipoentorno;
	}


	public void setTipoentorno(String tipoentorno) {
		this.tipoentorno = tipoentorno;
	}

	@Override
	public void run() {
		if(tipoentorno.equals("EDF")  ) {

		entorno.iniciasesionEDF();
		}
	

		
		 if (tipoentorno.equals("EPP") ) {
			entorno.iniciasesionEPP();
		}
		
	}
	




	@Override
	public String toString() {
		return "Desarrollador [entorno=" + entorno + ", nombre=" + nombre + ", tipoentorno=" + tipoentorno + "]";
	}
	
	
}
